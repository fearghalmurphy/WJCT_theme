<?php
/**
 * Title: CatPicks Featured By
 * Slug: twentytwentyfive-child2/catpicks-featured-by
 * Inserter: no
 */
global $post;
?>
<!-- wp:group {"style":{"spacing":{"blockGap":"0.2em","margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"accent-4","fontSize":"small","layout":{"type":"flex","flexWrap":"wrap"}} -->
<div class="wp-block-group has-accent-4-color has-text-color has-link-color has-small-font-size" style="margin-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:paragraph -->

	<?php 
	$featured = get_post_meta($post->ID,'featured_by', true);
	if ($featured) { 
	?>	
	<p class="featured-by">Featured by <?php echo $featured; ?></p>
	<?php 
	} 
	?> 
	
	<!-- /wp:paragraph -->

</div>
<!-- /wp:group -->
