<?php
/*
WJCT Child functions
*/ 


/* 
Enqueue style & Googgle fonts
*/ 
add_action( 'wp_enqueue_scripts', function() {
  wp_enqueue_style( 'twentytwentyfive-child-style33', get_stylesheet_directory_uri() . '/style.css' );
  wp_enqueue_style( 'palette-mosiac', 'https://fonts.googleapis.com/css2?family=Palette+Mosaic&display=swap' );
  wp_enqueue_style( 'oswald', 'https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap' );
});


add_filter( 'footer-text', 'footer_text' );

function footer_text( $credit ) {

    return 'Site by <a href="/">Me!</a>';

}

add_filter( 'render_block_template_part', function( $html, $slug, $meta ) {
    if ( 'site-title' === $slug ) {
        echo 'ahskdhaksjdhasjkd';
    }
    return $html;
}, 10, 3 );